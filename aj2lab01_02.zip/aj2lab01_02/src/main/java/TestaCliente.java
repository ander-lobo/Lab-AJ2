/*
 * Globalcode - "The Developers Company"
 * 
 * Academia do Java
 */
class TestaCliente {

    public static void main(String[] args) {
        // Criacao do cliente
        // Inicializacao do cliente
        // Impressao dos dados do cliente
    	Cliente a = new Cliente();
    	a.inicializaCliente("Anderson Lobo", "042.063.001-51");
    	a.imprimeDados();    	
    }
}
