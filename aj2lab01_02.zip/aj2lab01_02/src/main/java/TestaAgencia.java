/*
 * Globalcode - "The Developers Company"
 * 
 * Academia do Java
 */
class TestaAgencia {

    public static void main(String[] args) {
        // Criacao da agencia
        // Inicializacao da agencia
        // Impressao dos dados da agencia
    	Agencia a = new Agencia();    	
    	a.inicializaAgencia("0551", 1);
    	a.imprimeDados();
    }
}
