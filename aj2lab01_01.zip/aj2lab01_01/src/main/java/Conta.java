/*
 * Globalcode - "The Developers Company"
 * 
 * Academia do Java
 * 
 * 1) Adicione os seguintes atributos na classe Conta: 
 * - saldo (double) 
 * - numero (String) 
 * - titular (String) 
 * - agencia (int) 
 * - banco (int)
 */
class Conta {
	double saldo;
	String numero;
	String titular;
	int agencia;
	int banco;
}
